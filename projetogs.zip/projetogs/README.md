# Projeto EnergyWise GS Fiap
# Thomaz Morais Neves Rm:557789
