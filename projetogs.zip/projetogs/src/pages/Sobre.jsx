import styled from "styled-components"
import FaixaAzul from "../components/FaixaAzul"


const Container = styled.div`
    padding-top:50px;
`;


const Sobre = () => {
    return (
    <>
    <Container>
        <FaixaAzul titulo="Sobre Nós" paragrafo="Como tudo começou"></FaixaAzul>
    </Container>
    <div className="py-10">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
                Como Começamos
            </h3>
            <p className="text-black-700 text-lg">
            Nossa empresa nasceu da ideia de transformar o setor em que atuamos, trazendo inovação, eficiência e sustentabilidade para o mercado. Começamos com uma equipe pequena, mas muito comprometida, que acreditava que era possível criar soluções que fossem não apenas rentáveis, mas também responsáveis com o meio ambiente. A visão de que a sustentabilidade não deveria ser uma opção, mas uma prioridade, nos motivou a dar os primeiros passos, sempre buscando atender a uma demanda crescente por alternativas mais ecológicas e eficientes.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
                De Onde Veio a Ideia
            </h3>
            <p className="text-gray-700 text-lg">
                A inspiração para fundar a empresa veio da constatação de que o mercado estava pronto para mudanças. Percebemos que as soluções tradicionais não estavam mais atendendo às necessidades de um público cada vez mais exigente, que busca por empresas comprometidas com o meio ambiente e com a inovação. A ideia surgiu, então, da necessidade de conectar a sustentabilidade com a eficiência operacional, criando um modelo de negócios que não só resolvesse problemas, mas também fosse capaz de gerar um impacto positivo e duradouro no planeta.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
                Como Ela Funciona
            </h3>
            <p className="text-gray-700 text-lg">
            Hoje, a empresa funciona com base em princípios de inovação constante e práticas sustentáveis. Nossa operação é totalmente orientada por tecnologia de ponta, que nos permite otimizar processos e entregar soluções personalizadas aos nossos clientes. Trabalhamos com uma abordagem colaborativa e ágil, onde todos os projetos são desenvolvidos com foco nas necessidades específicas de cada cliente. Além disso, estamos sempre atentos às tendências do mercado e às novas tecnologias, garantindo que nossa empresa permaneça na vanguarda e continue a promover soluções inteligentes e sustentáveis.
            </p>
          </div>
        </div>
      </div>
    
    </>
    )
}

export default Sobre
