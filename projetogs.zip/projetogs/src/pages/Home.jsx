import styled from "styled-components";
import FaixaAzul from "../components/FaixaAzul";
import SlideShow from "../components/SlideShow";

const Container = styled.div`
  padding-top: 50px;
`;

const Carrossel = styled.div`
  width: 100%;
  height: 100vh; /* Garante que ocupe a altura da tela */
`;

const Home = () => {
  return (
    <>
      <Container>
        <div className="relative flex items-center justify-center text-center bg-black px-10 py-6">
          <div>
            <p className="text-sm text-white">
              <strong className="font-semibold">EnergyWise</strong>
              <svg
                viewBox="0 0 2 2"
                className="mx-2 inline size-0.5 fill-current text-white"
                aria-hidden="true"
              >
                <circle cx="1" cy="1" r="1" />
              </svg>
              Está cansado de sempre pagar caro na conta de luz? Aqui você encontra
              a melhor forma de economizar e ajudar o planeta!!
            </p>
          </div>
        </div>
      </Container>
      <Carrossel>
        <SlideShow />
      </Carrossel>
      <FaixaAzul
        titulo="Nosso diferencial"
        paragrafo="Conheça mais sobre nós e como podemos mudar sua vida"
      />
      
      {/* Seção de Cards */}
      <div className="py-10">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
            SUSTENTABILIDADE
            </h3>
            <p className="text-black-700 text-lg">
              Na nossa empresa, acreditamos que o futuro é verde. Por isso, investimos em soluções sustentáveis que utilizam energias renováveis e práticas ecoeficientes. Nossos produtos e serviços são pensados para reduzir o impacto ambiental, contribuindo para um mundo mais limpo e equilibrado.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
              Atendimento
            </h3>
            <p className="text-gray-700 text-lg">
              Somos líderes na adoção de tecnologias de ponta. Utilizamos inteligência artificial e IoT para otimizar processos e criar soluções inteligentes, trazendo aos nossos clientes mais controle e eficiência. Inovar é a nossa essência, e estamos sempre à frente para oferecer o melhor.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
              Inovação Tecnológica
            </h3>
            <p className="text-gray-700 text-lg">
            A implementação da plataforma descentralizada promove benefícios sociais, econômicos e ambientais. Ao permitir que usuários vendam sua própria energia, os custos energéticos são reduzidos, especialmente em comunidades remotas. A solução também fomenta a criação de empregos no setor de energias renováveis e fortalece a economia local. Além disso, ao incentivar práticas de geração e consumo sustentável, a plataforma contribui diretamente para a redução da pegada de carbono global e para a conscientização sobre a transição energética.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
