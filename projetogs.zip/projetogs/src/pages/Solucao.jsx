import styled from "styled-components"
import FaixaAzul from "../components/FaixaAzul"


const Container = styled.div`
    padding-top:50px;
`;


const solucao = () => {
    return (
    <>
    <Container>
        <FaixaAzul titulo="Solução" paragrafo="Como mudamos a sua vida e a de milhões de pessoas que usam nossa plataforma"></FaixaAzul>
    </Container>
    <div className="py-10">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
              Como É Feito
            </h3>
            <p className="text-black-700 text-lg">
            Nosso processo começa com uma análise detalhada das necessidades de cada cliente. A partir disso, desenvolvemos soluções personalizadas, com base em tecnologias inovadoras e práticas sustentáveis. Cada projeto passa por uma etapa de planejamento, onde nossa equipe trabalha de forma colaborativa para garantir que as soluções sejam eficazes e atendam aos objetivos de nossos clientes. Utilizamos as melhores ferramentas disponíveis para otimizar processos e proporcionar resultados de alta qualidade, sempre com um compromisso com a sustentabilidade e eficiência.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
              Como Muda a Vida do Cliente
            </h3>
            <p className="text-gray-700 text-lg">
              Nossas soluções não apenas resolvem os desafios imediatos dos nossos clientes, mas também proporcionam um impacto transformador em seus negócios e no seu dia a dia. Ao adotar nossas soluções sustentáveis e tecnológicas, os clientes experimentam uma maior eficiência operacional, redução de custos e um alinhamento com práticas mais conscientes e ecológicas. Isso não só melhora a performance dos seus negócios, mas também contribui para um futuro mais sustentável, permitindo que se tornem líderes no seu setor em termos de inovação e responsabilidade ambiental.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white shadow-md rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-teal-500 ">
              O Feedback dos Clientes
            </h3>
            <p className="text-gray-700 text-lg">
              Acreditamos que o feedback dos nossos clientes é uma parte essencial do nosso crescimento. Sempre buscamos ouvir atentamente as opiniões e sugestões dos nossos clientes, tanto durante quanto após a entrega dos serviços. Esse retorno nos permite ajustar e aprimorar nossas soluções, garantindo que estamos sempre alinhados às suas necessidades e expectativas. Nosso compromisso com a melhoria contínua se reflete em nossa disposição para aprender com cada interação e fornecer um serviço cada vez mais personalizado e eficiente.
            </p>
          </div>
        </div>
      </div>
    
    </>
    )
}

export default solucao
