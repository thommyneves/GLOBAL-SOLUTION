import styled from "styled-components";
import { Link } from "react-router-dom";


const NavBar = styled.nav`
    
    background-color: #01DFD7;
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 10;
`;

const NavContainer = styled.div`
    display: flex;
    justify-content: space-between;
    color: black;
    align-items: center;
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px; 
`;

const NavSection = styled.div`
    display: flex;
    align-items: center;
    gap: 40px;
    color: black;
    @media (max-width: 768px) {
    gap: 10px;
    }
`;


const NavLink = styled(Link)`
    font-family: poppins;
    text-decoration: none;
    color: BLACK;
    font-weight: bold;
    text-shadow: 2px 2px solid black;
    transition: color 0.3s ease, transform 0.3s ease;
    &:hover {
    transform: scale(1.05); 
    }
`;


const ButtonLink = styled(Link)`
    padding: 1rem;
    padding-block: 0.5rem;
    background-color: black;
    color: white;
    border-radius: 24px;
    font-weight: bold;
    text-decoration: none;
    display: inline-block;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);

    &:first-of-type {
    background-color: black;
    }

    &:last-of-type {
    background-color: #black;
    } 
`;

const Nav = () => {
    return (
    <NavBar>
        <NavContainer>
            <NavSection>
            <NavLink to="/">EnergyWise</NavLink>
            </NavSection>
            <NavSection>
                <NavLink to="/">HOME</NavLink>
                <NavLink to="/sobre">SOBRE</NavLink>
                <NavLink to="/solucao">SOLUÇÃO</NavLink>
                <ButtonLink to="/cadastrar">CADASTRAR</ButtonLink>
                <ButtonLink to="/login">LOGIN</ButtonLink>
            </NavSection>
        </NavContainer>
    </NavBar>
    );
};

export default Nav;
